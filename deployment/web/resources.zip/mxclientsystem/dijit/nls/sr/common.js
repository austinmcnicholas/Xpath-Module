//>>built
define("dijit/nls/sr/common",{buttonOk:"U redu",buttonCancel:"Otkaži",buttonSave:"Sačuvaj",itemClose:"Zatvori"});
